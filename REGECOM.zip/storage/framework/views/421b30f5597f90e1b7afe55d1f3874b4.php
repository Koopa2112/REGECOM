

<?php $__env->startSection('title', 'Asesores'); ?>

<?php $__env->startSection('contenido'); ?>

<main>
    <div class="container py-4">
        <h2>Listado de asesores</h2>

        

        <a href="<?php echo e(url('asesores/create')); ?>" class="btn btn-primary btn-sm">Nuevo Asesor</a>
    </div>
</main>

<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\REGECOM\resources\views/asesores/index.blade.php ENDPATH**/ ?>